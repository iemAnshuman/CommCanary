"""Compilation capability tests."""
