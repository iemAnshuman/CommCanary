"""Comparison capability tests."""
