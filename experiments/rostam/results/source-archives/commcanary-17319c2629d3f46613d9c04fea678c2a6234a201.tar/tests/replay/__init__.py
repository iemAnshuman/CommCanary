"""Replay capability tests."""
