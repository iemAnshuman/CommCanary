"""Adapter capability tests."""
