"""Verification capability tests."""
